#ifndef NNN_H
#define NNN_H


class nnn
{
    public:
        nnn();
        virtual ~nnn();

    protected:

    private:
};

#endif // NNN_H
