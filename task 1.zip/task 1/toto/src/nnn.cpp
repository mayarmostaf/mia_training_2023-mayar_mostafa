#include "nnn.h"

nnn::nnn()
{
    //ctor
}

nnn::~nnn()
{
    //dtor
}
