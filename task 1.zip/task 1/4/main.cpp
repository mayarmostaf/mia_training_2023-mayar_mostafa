#include <iostream>

using namespace std;

int main(){
    int q;
cin>>q;
    if ((q<=0)||(q>30)){
        cout<<"please enter no between 1 and 30\n";
        cin>>q;
    }
    for(int i=0;i<q;i++){
     int n;
     cin>>n;
     int x[n];
     int y[n];
     for(int i=0;i<n;i++){
      cin>>x[i];
        }
     for(int j=0;j<n;j++){
        int m=0;
        int great=0;
        for(int k=j+1;k<n;k++){
           if (x[k]>great){
            m++;
            great=x[k];
           }
           if (x[j]<x[k]){
            break;
           }

        }
        cout<<m;

        }}


    return 0;
}
