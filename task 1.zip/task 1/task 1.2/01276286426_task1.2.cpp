#include <iostream>
#include <cmath>
using namespace std;

int main()
{
  int q=0;
  int hp=0;
  int H=0;
  int P=0;
    cout<<"please enter no of test cases\n";
    cin>>q;
    if ((q<=0)||(q>30)){
        cout<<"please enter no between 1 and 30\n";
        cin>>q;
    }
    //loop for test cases
    for(int i=0;i<q;i++){
     cout<<"please enter:\nhp   P   H\n";
     cin>>hp>>P>>H;
     while((hp<1)||(hp>pow(10,5))){cout<<"error"<<endl;cin>>hp>>P>>H;}

     if(P>30){//make sure max no of p is 30
        P=30;
     }
     if(H>30){//make sure max no of H is 30
        H=30;
     }
     //at the most benefit of weapons case we use all p then h
     for(int j=0;j<P;j++){//loop to use all p
        hp=floor(hp/2)+10;
     }
     hp=hp-H*10;//using all h
     if (hp<0){//knowning if defeated or not
        cout<<"yes"<<endl;
     }else if(hp>0){
         cout<<"no"<<endl;
     }}


    return 0;
}
