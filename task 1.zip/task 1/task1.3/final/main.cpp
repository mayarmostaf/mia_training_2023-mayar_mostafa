#include <iostream>
#include <string>
#include <map>
using namespace std;

int main()
{
    int q=0;
    string x;
    map <string,string> m;
    m["1"]="a";
    m["2"]="b";
    m["3"]="c";
    m["4"]="d";
    m["5"]="e";
    m["6"]="f";
    m["7"]="g";
    m["8"]="h";
    m["9"]="i";
    m["10&"]="j";
    m["11&"]="k";
    m["12&"]="l";
    m["13&"]="m";
    m["14&"]="n";
    m["15&"]="o";
    m["16&"]="p";
    m["17&"]="q";
    m["18&"]="r";
    m["19&"]="s";
    m["20&"]="t";
    m["21&"]="u";
    m["22&"]="v";
    m["23&"]="w";
    m["24&"]="x";
    m["25&"]="y";
    m["26&"]="z";

    cin>>q;
    if ((q<=0)||(q>30)){
        cout<<"please enter no between 1 and 30\n";
        cin>>q;
    }
    for(int i=0;i<q;i++){
    string y;
    cin>>x;
    int j=0;
    int z=x.size();
     while(j<=z){
      if((x[j+2]=='&')&&(j<=(z-2))){
      y.append(m[x.substr(j, 3)]);
      j=j+3;
      } else{
      y.append(m[x.substr(j,1)]);
      j=j+1;
      }
     }
     cout<<y<<endl;
    }
    return 0;
}

