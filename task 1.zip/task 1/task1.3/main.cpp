#include <iostream>
#include <string>
using namespace std;

int main()
{
    int q=0;
    string x;
    cin>>q;
    if ((q<=0)||(q>30)){
        cout<<"please enter no between 1 and 30\n";
        cin>>q;
    }
    for(int i=0;i<q;i++){
        cin>>
    }
    return 0;
}
