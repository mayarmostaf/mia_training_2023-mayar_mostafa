#include <iostream>

using namespace std;

int main(){
    int q;
cin>>q;
    if ((q<=0)||(q>30)){
        cout<<"please enter no between 1 and 30\n";
        cin>>q;
    }
    for(int i=0;i<q;i++){//loop for test cases
     int n;
     cin>>n;//taking size of current test case array
     int x[n];//creating array with size n
     for(int i=0;i<n;i++){//loop for taking each creature height from user
      cin>>x[i];
        }
     for(int j=0;j<n;j++){//loop on each creature to know of creature its seeing
        int m=0;//creating m to represent no of creature seen
        int great=0;//creating great to represent the tallest creature the j creature is seeing
        for(int k=j+1;k<n;k++){//loop on creatures after j creature to know which of them it sees
           if (x[k]>great){//if it is greater than the greatest till now so it is seen and m inc by 1
            m++;
            great=x[k];//and it is the greatest now
           }
           if (x[j]<x[k]){//if the creature is taller than the creature seeing it so it will be seen according to previos if but no other next creatures willbe seen so we should break the loop
            break;
           }

        }
        cout<<m;//printing no of seen creatures for each one

        }}


    return 0;
}
