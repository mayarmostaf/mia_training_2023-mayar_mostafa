#include <iostream>
#include <string.h>
#include <vector>
#include "user.h"
#include "robot.h"
using namespace std;
void display_us();
void search_us(string name);
int nu=0;
vector <user> users ;
void creat_u()

void display_rs();
void search_rs(string name);
int nr=0;
vector <robot> robots ;
void creat_u()


int main()
{        int x;
            string nnn;
            int ttt;
            string eee;
            int ppp;
            string fff;
            vector<int>ffr;

     cout<<" enter no of required operation:\n 0:Add robot:\n 1:Add user: \n 2:Display all users: \n 3:Display all robots: \n 4:Search for robot by name:\n 5:Search for user by name:\n 6:Rent robot to user:\n 7:Exit"<<endl;
     cin>>x;
while(x!=7){
    switch(x){
        case 0:

            cout<<"name:";
            cin>> nnn;
            cout<<"price per day:";
            cin>>ppp;
            robots[nr]=robot(nnn,ppp);
            cout<<"func_id";
            cin>>fff;
            cout<<"fffff";
            nr++;
        /*  for (int i=0;i<=fff.size();i=i+2){
                ffr.push_back((int)fff[i]);
          }
*/

        break;
        case 1:
            nu++;
            cout<<"name:";
            cin>> nnn;
            cout<<"telephone:";
            cin>>ttt;
            cout<<"e_mail:";
            cin>>eee;
            users[nu]=user(nnn,ttt,eee);
            break;
        case 2:
            display_us();
        break;
        case 3:
           display_rs();
        break;
        case 4:
            cout<<"name:";
            cin>> nnn;
            search_us(nnn);
        break;
        case 5:
            cout<<"name:";
            cin>> nnn;
            search_rs(nnn);
        break;
        case 6:
        break;

    }
     cin>>x;
    }


    return 0;
}
void display_us (){
   for(int i=0;i<=nu;i++){
      users[i].display_u();
}}
void search_us(string name){
for(int i=0;i<nu;i++){
    if(users[i].name==name)
    {
        cout<<"found"<<endl;
        users[i].display_u();
        break;
     }
     else if (i==nu-1){
         cout<<"not found"<<endl;
     }
}}
void display_rs (){
   for(int i=0;i<=nr;i++){
      robots[i].display_r();
}}
void search_rs(string name){
for(int i=0;i<nr;i++){
    if(robots[i].name==name)
    {
        cout<<"found"<<endl;
        robots[i].display_r();
        break;
     }
     else if (i==nr-1){
         cout<<"not found"<<endl;
     }
}}
