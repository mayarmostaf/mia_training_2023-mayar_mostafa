#include "robot.h"
#include <iostream>

using namespace std;
robot::robot(string name,int pricepd)
{
}
void robot::display_r(){
 cout<<name;
 cout<<pricepd;
 cout<<rented<<endl;
 }
robot::~robot()
{

}
