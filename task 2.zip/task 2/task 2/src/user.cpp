#include "user.h"
#include <iostream>
using namespace std;
user::user(){}
user::user(string n ,int t,string e):name(n),tele(t),e_mail(e)
{

}
 void user::display_u(){
 cout<<name;
 cout<<tele;
 cout<<e_mail<<endl;
 }


user::~user()
{

}
