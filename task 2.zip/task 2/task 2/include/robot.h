#ifndef ROBOT_H
#define ROBOT_H
#include <string>
#include <vector>
#include <iostream>

using namespace std;
class robot
{
    public:
        robot(string name,int pricepd);
        virtual ~robot();
        string name;
        vector <int> f_id ;
        int pricepd;
        bool rented ;
       vector <string> days ;
       int f;
       void display_r();
    protected:

    private:
};

#endif // ROBOT_H
