#ifndef USER_H
#define USER_H
#include <string>
#include <vector>
#include <iostream>
using namespace std;
class user
{
    public:
        user();
        user(string n,int t,string e);
        virtual ~user();

        string name ;
        int tele ;
        string e_mail ;
        vector <string> arr_rented;
        void display_u();


    protected:

    private:
};

#endif
