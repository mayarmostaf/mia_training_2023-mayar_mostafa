#include <stdlib.h>

int main(void)
{   // make bits in position setted in mask , move the value bits in this positions in value to x .
    /*unsigned char x=0xd1;
    unsigned char mask =0x22;
    unsigned char value =0x3f;
    value=mask&value;
    x=x&~mask;
    x=x|value;
    printf ("%X",x);
    */
    //to genrate a rotate for x with n times ,which not supported by c.
   /* unsigned char x=0xd1;
    unsigned char n =3;
    x=(x>>n)|(x<<(8-n));
    printf ("%X",x);*/
//how to do ceil by my self

   /* int x=5;
    int y=2;
    int ceil;
    ceil=(x+y-1)/y;
    printf ("%i",ceil);*/
    /*int x=5;
    int y=2;
    int ceil;
    ceil=(x%y)?(x/y)+1:x/y;
    printf ("%i",ceil);*/
 //casting signed and unsigned ,tc of that except you know.
   /* signed char x=0x80;
    unsigned short y;
    signed short z;
    y=x;
    z=x;
printf("%x\n%x\n",y,z);
printf("%d\n%d\n",y,z);*/

    return 0;
}
