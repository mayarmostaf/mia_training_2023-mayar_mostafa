#include <iostream>
#include <string.h>
using namespace std;

int main()
{
    string d;
    cout << "Hello world!" << endl;
    return 0;
}
